
In this lab the input is within a html form `<input>` tag which allows for functions to be called 

![[Pasted image 20250313154510.png]]
for this we can use the onMouseOver function to then run some javascript 

so imputting 
``` JavaScript
"onMouseOver="alert(1)
```

bypasses the filter, when you mouse over the search bar the alert is thrown 