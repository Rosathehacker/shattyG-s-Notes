
in a commant section entering <script>alert(1)</script> and submitting it makes an alert ping evertime the page is loaded 