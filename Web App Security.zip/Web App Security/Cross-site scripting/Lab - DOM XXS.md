this lab uses the `document.write` function that writes data to the page. it is called from `location.search ` that controls the website url


the serach term is being loaded in an `<img>` tag, 
```html
<img src="x/x/tracker.gif?searchTerms=example">
```

so if we break out of this by inputting  `"</script><script>alert(1)</script>` we get 


```html
<img src="x/x/tracker.gif?searchTerms=example"" <script>alert(1)</script>"
```

this execuetes the javascript