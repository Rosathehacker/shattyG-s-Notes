
when you enter search term is is displayed on site as heading 

adding <script>alert(1)</script> into the search fires an alert 