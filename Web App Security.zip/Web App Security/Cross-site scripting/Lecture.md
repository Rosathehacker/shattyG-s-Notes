## What is JavaScript

- [[javascript]] is the programming language of the web 
- it can update and change both html and css
- it can calculate, manipulate and validate data 
- vast majority of website use it for client side page behaviour 
- <script> alert('Hello');</script>



## What is Cross-site scripting 

>DEFINITION 
>
> cross site scripting is a web vulnerability that allows an attacker to compromise the interactions that users have with a vulnerable application 

- It allows attackers to circumvent the same origin policy (SOP), which 

- XXS may allow an attcker to masquerade as a victim


## how XSS works 
- the website orks by manipulating a vulnerable web site that it returns malicious JavaScript to users
- wen the malicious code is ex

## Circumventing SOP
- the **same origin policy** is a security mechanism that prevents scripts on one website from interacting with another websites resorces 
- since the malicious script is executed ss if it came form the legitimate site, SOP does not block it 

## Impacts
- depends on the nature of the applictaion, its functionality and data and the stus f the compromised user.

## Types of XSS

- Reflected XSS
	- most common type of XSS
	- arises when a web app receives data in an HTTP request and include that data within the immediate response in an unsafe way 
	- if the user vistis the url 
- in reflected the user must clock a malicious url

- example
``` 
https://insecuresite.com.status?message=All 
```

### exploiting Reflection XSS 

1. the user logs in
2. f





### stored XSS
- This version arises when daya is submitted by one user is stored in the web app(typically a database)
- adn then is displayed to other users without being filyered or sanitised properly 

in stored 

### DOM based XSS
- DOM document object model 
- defines yje logical structure of a website 
- the # sign is used for uri fragments 
	- this is a way of showing section of the page 
- an attack where the payload is executed as a result of moding the DOM enviromeny
- the HTTP response for

## Mitigation

- encoing data on input:
	- encoding should be applied directly before befefor the user controlled date is written to the page 
- in HTML context you could convert non-whitelisted values into HTML entities 
	- < converts to &lt;
	- > converts to &gt;
- in JavaScript sting context, non alphanumeric is converted to unicode
- validate input 
	- validate tat the expected to be numberic validate tha the value actllt contains an interger

## bypassing mitigations 

- a webapp may remove or sanitise cerin keywords 
- use both lower and upper case letters
``` HTML
<scrRIpt>alert(1)</sCriPt>
```
- adding spaces to tags 
```HTMl
<script >alert(1)</sctipt>
```
- using recursive tags 
```html
<src<script>alert(1)</script>ript>
```

- this is used if the javascript is already in a clock of text, you can see where the script is using view-source.
```html
"</script><script>alert(1)</script>
```

``` JavaScript
';alert(1); //
```
- they may block **alert**
``` html
<script>prompt(1)</script>
```
using img src errors
``` html
<img src='zzzz' onerror='alert(1)'/>
```


