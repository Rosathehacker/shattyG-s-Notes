
Sensitive data can be leaded in all kinds of places, so it important not to miss anything that could be useful. You will often find sensitive data while testing for something else.

A key sill is being able to recognize interesting information whenever and wherever you do come across it 


## Tools and techniques  
The following are some techniques and tools that can help you identify information disclosure vulnerabilities 

- [[Fuzzing]]
	- if you find interesting parameters you can try submitting unexpected data types and specially crafted fuzz strings 
	- Pay close attention; although responses sometimes explicitly disclose interesting information, they can also hint at the application's behaviour more subtly.
	- For example, this could be a slight difference in the time taken to process the request. Even if the content of an error message doesn't disclose anything, sometimes the fact that one error case was encountered instead of another one is useful information in itself. 
-   [[burp intruder]]

#WebVulnerability 