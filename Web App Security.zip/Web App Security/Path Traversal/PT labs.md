
## Reading arbitrary files via path traversal 

### scenario:
-  application displays an image using the URL
``` html
<img src="/loadImage?filename=218.png">
```

### processing:
- the server appends the filename to the based directory (`/var/www/images`) and reads
``` bash
/var/www/images/218.png 
```

### exploiting path traversal:

- malicious input:
```
https://insecure-website.com/loadImage?filename=../../../etc/passwd
```

- the system reads this as 
```
/var/www/images/../../../etc/passwd
```

- Starting at `/var/www/images/`, the first `../` moves up to `/var/www/`.
- The next `../` moves up to `/var/`.
- The third `../` moves up to the root directory `/`.
- Finally, appending `etc/passwd` yields:
``` bash
/etc/passwd 
```

## Common obstacles to exploiting path traversal 

### Using absolute paths 

- Many applications incorporate defences to stop attackers from exploiting file path inputs. These defences often include measures like stripping out or blocking known traversal sequences (e.g., "../"). However, attackers have developed several techniques to bypass these protections.

- Even if an application is designed to remove or block relative path traversal sequences, it may still allow file paths that start from the filesystem root.
- If an attacker provides an absolute path directly (for example, `filename=/etc/passwd`), the application might not detect any forbidden patterns because it isn’t using the traditional `../` sequences.

 - Instead of injecting `../../../etc/passwd`, an attacker might simply use:
```
https://insecure-website.com/loadImage?filename=/etc/passwd
```

- Since the filter is only looking for relative traversal markers, it fails to block the absolute path. The server then directly reads `/etc/passwd`, potentially exposing sensitive system data.

###