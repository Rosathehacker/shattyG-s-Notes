path traversal is a vulnerability that enables enables attackers to manipulate file path inputs. This is often done by including sequences like `../` allowing access to files and directories that wasn't intended by the developers.

## How it works

### Input manipulation 

- an application that accepts user input such as a file name or path that does not use proper sanitation can be tricked into accessing files beyond the intended scope 
- **Example**
	- consider a web app that builds file paths by concatenating a base directory with user input
``` PHP
$file = $_GET['file'];
include('/var/www/html/files/' . $file);
```

- for linux systems an attacker could send this request
``` http
http://example.com/view.php?file=../../../../etc/passwd
```

- this request is attempting to move up the directory using `../`. using 4 of them leads to the base directory of the system `/` and then trying to access `/etc/passwd` file 


- for windows the attacker could send this request 
``` http
http://example.com/view.php?file=..\..\windows\win.ini
```

- this requets is using  `..\` to move up to to the based of the drive and then to the `win.ini` file

#WebVulnerability 

