## Authentication Vulnerabilities 

Authentication vulnerabilities can allow attacker to access sensitive data and functionality, they also expose adnominal attack surfaces for further exploits.


### What is  Authentication

authentication is the process of verifying the identity of users or clients. websites are potentially exposed to anyone who is connected to the internet, making robust authentication a vital part of web security.

authentication can be split into 3 main categories:
- something you **know**: such as passwords or security questions 
- Something you **have**: This is a physical object such as a phone or security key 
- Something you **are** or **do**: This can be a biometrics or patterns of behaviour 

Authentication mechanisms rely on a range technologies to verify one or more of these factors 


### What is the difference between authentication and authorisation

- Authentication:
	- This is the process of verifying the user is who they say they are
	- for example password
- Authorisation:
	- The process of verifying if the user can do something 
	- for example permissions


### How do authentication vulnerabilities arise 

Most authentication vulnerabilities occur in one of two ways:

- the authentication mechanisms are weak because they fail to adequately protect against brute-force attacks 
- Logic flaws or poor coding in implementation allows authentication mechanism to be bypassed entirely by an attacker. This is sometimes called broken authentication



Authentication vulnerabilities are usually critical meaning any logic flaws should be investigated fully as they usually lead to security issues  

#WebVulnerability 