
```



NEED TO FILL FROM LECURE slides  COS LATE 

```



## How to prevent business logic flaws

- note any refernces to other code that uses each component 
	- think about any side effects of these dependencies if a malicous party were to manipulate them in an unusual way 
- maintain clear design documents and data flows for all transactions and workflows, noting any assumptions that are made each stage 
- write coe as clearly as possible 
	- if its difficult to understand what is supposed to happen, it will be difficult to spot logic flaws 

