when adding item to cart it declared the price in the post request when adding to cart 
![[Pasted image 20250403145742.png]]
![[Pasted image 20250414101948.png]]
modifying the price parameter changed the price of the item in the cart, allowing the item to be purchased cheaper than intended 

