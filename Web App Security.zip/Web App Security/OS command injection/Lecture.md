## What is os injection 
- os command injection allows an attacker to execute operating system commands on the server that is running a web app

## Impact
- often an attcker can use an is command injection 
- infrastructure could be compromised abd trust relationships explouted ti pivot the attacker to other systems


- functions commonly used to issure os command 
	- exec in php 

## Examples 
- a cloud storage app has a function to display avalible storage 

```
https://dropbox/space.cgi?dir=phots
```

``` python
import subprocess
command = "du"
```

example 2 

$command = du -h "path/to/file "



shell meta character 

- ; - php
- &, && | and ||