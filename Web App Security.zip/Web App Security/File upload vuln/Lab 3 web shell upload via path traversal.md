in lab 3  it when you try and upload a php file it says it does but you cannot access it 
![[Pasted image 20250327153358.png]]


so we have to leave this directory as we dont have permission 

we do this with a `../` but this also doesnt work 

so we use URL encoding by using `..%2f`
![[Pasted image 20250327153609.png]]

then by accessing `/files/lab3.php` rather than `/files/avatars/lab3.php`

we then get the data we need form /secret