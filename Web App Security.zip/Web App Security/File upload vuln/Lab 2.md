file upload is blocking .php files 
in burp change the `content-type` in the request to upload the file to `image/jpeg` and the upload should work 