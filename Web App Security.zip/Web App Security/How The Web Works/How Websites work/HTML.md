HyperText Markup Language (HTML) is the language that websites are written in

### Elements 
Elements (or Tags) are the used to define aspects of a web page some common ones are:

- The `<!DOCTYPE html>` defines that the page is a HTML5 document. This helps with standardisation across different browsers and tells the browser to use HTML5 to interpret the page.
- The `<html>` element is the root element of the HTML page - all other elements come after this element.
- The `<head>` element contains information about the page (such as the page title)
- The `<body>` element defines the HTML document's body; only content inside of the body is shown in the browser.
- The `<h1>` element defines a large heading
- The `<p>` element defines a paragraph
- The `<img>` element defines an image
- the `<button>` element defines a clickable button 


tags can contain attributes such as `class` witch can be referenced in [[CSS]] in order to add styling to the element  
``` HTML
<p class="bold-text">
```

or the `src` attribute can be used on `<img>` to specify the location of the images to be displayed 
``` HTML
<img src="img/cat.jpg">
```

It is also possible for an element to have multiple tags 
``` HTML
<p attribute1="value1" attribute2="value2">
```

Elements can also have an `id` attribute, this allows for the element to have a unique id, unlick the `class` that can be applied to multiple elements 
``` HTML
<p id="example">
```

### Example

The following is some HTML that is needed for any webpage

``` HTML
<!DOCTYPE html>
<html>
	<head>
		<title>Page Title</title>
	</head>
	<body>
		<h1>Example Heading</h1>
		<p>Example paragraph</p>
	</body>
</html>
```

