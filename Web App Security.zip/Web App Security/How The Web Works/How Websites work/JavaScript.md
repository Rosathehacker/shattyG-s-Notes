 JavaScript is used to make a webpage interactive. It can be added to the page source by two methods:

it can be written directly in the document in the `<script>` tag
``` html
<script type="text/javascript">
	alert("Hello! This is a simple JavaScript alert.");
</script>
```

it can be included remotely by adding the `src` attribute to the `<script>` tag 
``` HTML
<script src="/location/of/javascript_file.js"></script>
```

The following JavaScript code finds a HTML element on the page with the id of "demo" and changes the element's contents to "Hack the Planet" :


``` JavaScript
document.getElementById("demo").innerHTML = "Hack the Planet";`
```

HTML elements can also have events, such as "onclick" or "onhover" that execute JavaScript when the event occurs.
The following code changes the text of the element with the demo ID to Button Clicked: 

``` HTML
<button onclick='document.getElementById("demo").innerHTML = "Button Clicked";'>Click Me!</button> 
```

- onclick events can also be defined inside the JavaScript script tags, and not on elements directly.