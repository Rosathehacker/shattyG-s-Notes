here are two major components that make up a website:

1. Front End (Client-Side) - the way your browser renders a website.
2. Back End (Server-Side) - a server that processes your request and returns a response.

These components communicate over the [[HTTP-HTTPS]] protocols
   ![[Pasted image 20250130190330.png]]
Websites are made of 3 primary components:

- [[HTML]] - This is used to define the structure of a webpage 
- [[CSS]] - This is used to make the website look pretty by adding styling 
- [[JavaScript]] - This is used to implement complex features allowing for interactivity 