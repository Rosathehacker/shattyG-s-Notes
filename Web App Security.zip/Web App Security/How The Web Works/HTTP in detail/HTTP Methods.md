#### **GET Request**
- This is used for getting information form web server 

#### **POST Request**
- This is used for submitting data to the webserver and potentially create new records

#### **PUT Request**
- This is used for submitting data to a webserver to update information 

#### **DELETE Request**
- This is used for deleting information/records form a webserver 