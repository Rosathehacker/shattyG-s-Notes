## HTTP
- HTTP stands for **HyperText Transfer Protocol**
- it is used to transmit webpage data, be it HTML, images, video, etc.

## HTTPS

- HTTPS is the secure version of HTTP, the S standing for secure  
- HTTPS data is encrypted so it not only stops people from seeing the data you are receiving and sending, but it also gives you assurances that you're talking to the correct web server and not something impersonating it.




[[URL]]
[[HTTP Methods]]
[[HTTP Status Code]]