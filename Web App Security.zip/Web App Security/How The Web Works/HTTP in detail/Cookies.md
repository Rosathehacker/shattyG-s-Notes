
Cookies are used to identify a user for personalised setting or cross site tracking

cookies can be set using the "Set-Cookie" header that is sent form the server 

Cookies can be viewed in the `developer tools -> network 

![[Pasted image 20250130183556.png]]