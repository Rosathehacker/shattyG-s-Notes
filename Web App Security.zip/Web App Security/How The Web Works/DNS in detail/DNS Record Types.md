## DNS Record Types

DNS isn’t just for websites, there are several types of DNS record

-   **A Record** – these record are for IPv4 addresses

-   **AAAA Record** – These records resolve IPv6 addresses

-   **CNAME Records** – are used to point an alias domain to a “canonical” domain. This alias is usally in the form of a subdomain, that makes another DNS request to the canonical domain

	-  eg **store.tryhackme.com** returns the CNAME record of **shops.shopify.com** to work out the ip address

-   **MX Records –** These records are used to resolve the address of the mail server for the domain. These record come with a priority flag. This tells the client in which order to try the servers this is perfect for if the main server goes down and email needs to be sent to a backup server

- **TXT Records -** are free text fields where any text-based data can be stored. TXT records have multiple uses, but some common ones can be to list servers that have the authority to send an email on behalf of the domain