## TLD (top level domain)

A TLD is the last section of a url i.e. **.com, .net, .org** etc.

 These can be separated into 2 types:

-   **gTLD** (generic top level domain)
	- historically this was used to tell the user the purpose of the site
	 - eg .com for commercial purposes, .edu for education, .gov for government
	- due to the growing demand for gTLDs there are now over 2000 TLDs such as .online and .biz

-   **ccTLD** (Country code top level domain)
	- used for geographical purposes
	- eg .ca for Canada, .co.uk for united kingdom

## Second-level domain

Taking **tryhackme.com** as an example

-   .com is the TLD
-   tryhackme is the second level domain

when registering a domain the **length is limited to 63 characters** + the TLD.

These characters much be alpha-numeric or hyphens (but cannot start or end with hyphens and cannot be consecutive)

## Sub-Domain

Sub-Domains are to the left of the Second-level Domain, separated with a full stop. A subdomain follows the same restrictions as the second-level domain (restricted to 63 characters and alapha-numeric)

A url can have multiple (no limit) subdomains, as long as the **total length is kept to 253**

For example **Jupiter.admin.tryhackme.com**

-   **Jupiter** is a subdomain

-   **admin**  is a  subdomain

-   **tryhackme** is the Second-level Domain

-   **.com** is the Top-level domain