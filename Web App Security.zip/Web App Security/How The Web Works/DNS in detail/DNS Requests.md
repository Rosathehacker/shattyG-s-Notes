# DNS Requests

1.       You request a domain name, first the cache is checked to see if it is there form previous lookups, if not a request to your recursive DNS server is made

2.       Recursive DNS servers are usually provided by ISP but one can be selected manually, the request is sent to this if one is found on the local recursive DNS server then the request is sent to the internet’s root DNS

3.       The root servers act as the DNS backbone of the internet. It is used to identify the correct DNS server to send the rest to, this is done by looking at the TLD  to send it to the correct TLD Server

4.       The TLD servers hold records on where to find the namespace server to answer the DNS request. It is common to find multiple namespace servers as a back if one goes down

5.  A **namespace** server is what is responsible for storing DNS records for particular domains and where any updates to the domain DNS records would be made. depending on the type of record, The DNS record would be sent back to the Recursive DNS server, here a copy of the record will be stored in the cache. All record come with a TTL (Time To Live) value, this is how long a record should be kept until it is refreshed 