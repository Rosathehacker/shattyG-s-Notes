## What is DNS  
  
The Domain Name System (DNS) is the phonebook of the Internet. Humans access information online through domain names nytimes.com or espn.com. Web browsers interact through Internet Protocol (IP) addresses. DNS translates domain names to IP addresses so browsers can load Internet resources.

[[DNS Record Types]]

[[Domain Hierarchy]]

[[DNS Requests]]