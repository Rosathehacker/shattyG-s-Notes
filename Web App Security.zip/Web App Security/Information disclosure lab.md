## Good source for information disclose 
- robots.txt - provides name of hidden directories 

## Testing for Information disclosure
- Fuzzing 
- burp scanner 