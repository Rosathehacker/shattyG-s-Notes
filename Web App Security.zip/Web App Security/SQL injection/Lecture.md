For SQLi you do need to know a little bit of SQL such as how queries are stucures as well as how databases are structured 

---
## What is SQLi
SQLi allows an attacker to interfere with queries that an app amke to its database. This allows attackers to view data hat they are not normaly able to view

This may include other users data or any other data that the app can access

in some situations an attacker can escalate an attack 


## Impact

- a successful SQLi attack can result in unauthorised access to sensitve data:
	- passwords 
	- credit card details
	- personal user information 
- SQLi attacks have been used in many high profile date breaches over the years
- causes reputational damage and regulatory fines
- in some cases attackers can obtain persistent backdoor into system, leading to long-term compromise that can go unnoticed 
## Examples

### Flow of information 

```
user (url) -> webserver (queiry)-> database (data)-> (webserver webage with data)-> user
```

- the web server and database (DB) server are aeperate entites 
- if manupulated the DB server has no cheacks on the dta being sent

### retrieving hidden data 

- almost every webapp uses a database to stor nfo 
- attackers can craft inputs that breaks out of the context

<font color="#7030a0">SELECT</font> <font color="#9bbb59">author,title,year</font> <font color="#7030a0">FROM</font> books <font color="#7030a0">WHERE</font> <font color="#9bbb59">publisher</font>= "<font color="#c00000">wiley</font>" <font color="#7030a0">and</font> <font color="#9bbb59">publisher</font> =1

where wiley is the input 

an attacker enter 



<font color="#c00000">wiley'  OR 1=1--</font>


making the full quivery:

<font color="#7030a0">SELECT</font> <font color="#9bbb59">author,title,year</font> <font color="#7030a0">FROM</font> books <font color="#7030a0">WHERE</font> <font color="#9bbb59">publisher</font>= "<font color="#c00000">wiley' OR 1=1--</font>" <font color="#7f7f7f">and publisher =1</font>

commenting out the rest of the the line 

this leads to the quiry now defaulting on true as 1=1 is always true, nullifying the WHERE statement, leading to all of the data being returned 

### injecting into diffrent types of statments 

- SELECT:
	- read data from the databse based on searching criteria 
- INSERT
	- insert new data into the datase
- UPDATE
	- update existing das base entries 

## Mitigation 

- you can prevent most instances of SQL injection using **parametrised statement**


- SQL query structure is fixed and placeholder (**?**) 
- this is safer as this input is treaded only as string 

## Bypassing mitigations

### Bypassing filters
- blocking '
	- the single quote is not required 
	- `?id=2 or 1=1`
- blocking --
	- insead of `'or 1=1--`
	- use `'or '1' ='1`

- blocking CAPS
	- some devs believe that statments have to be upper case 
	- SQL is case inessive meaning that using lower case maywork 
- other example
	- SeLeCt
	- %00SELECT
	- SELSELECTECT
- useing SQL commnets
	- rather than using -- you can ise `/**/`
	- `/**/` also works for bypassing space filter
	- an encoded tab (`%09`) can also be used to replace spaces
- not al attacks are to steal data 
	- 'shutdown --
	- 'drop table users --
	- 'drop table customers --
	