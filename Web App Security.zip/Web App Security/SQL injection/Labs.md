
## how to identify SQLi 

you can detect SQL injection manually using systematic set fo test against every entry point in the application to do this you would typically submit:

- the single quote `'` and look for errors or anomalies 
- some SQL specific syntax that evaluates to the based (original) value of the entry point , and to some different value and kiij fir systematic diffrences in the application resonses 
-  Bool