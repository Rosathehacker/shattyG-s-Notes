all http messages consist of:
- a **verb** indicating the method



