intruder - brute fo

[[Burp Suite]]

[[Information disclosure]]

[[Path traversal]]

[[Authentication]]

[[SQLi]]

[[OS command injection]]

[[XSS]]

[[Access Control]]

[[File Upload]]

[[Business Logic]]